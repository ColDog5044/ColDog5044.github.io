# ColDog-Locker README

## Compatability

| Operating System | Supported                         |
| ---------------- | --------------------------------- |
| Windows 11       | :heavy_check_mark:                |
| Windows 10       | :heavy_check_mark:                |
| < Windows 8.1    | :heavy_check_mark::grey_question: |
| macOS            | :x:                               |
| Linux            | :x:                               |

| OS Architecture | Supported          |
| --------------- | ------------------ |
| Windows 64 Bit  | :heavy_check_mark: |
| Windows 32 Bit  | :heavy_check_mark: |

# Important Notice
 - Your anti-virus may flag "ColDog-Locker.exe" and "ColDog-Locker Fixer.exe" as viruses. This is a false postitive.

## Disclaimer

By using this software, you agree that ColDog Studios is not held responsible for any data lost, stolen, or accessed.

Any unauthorized copying, distributing, or selling of this solftware is prohibited.

Do not type any blank or illegal characters into the prompts.

## Features

 - No hidden loading timers
 - Easy GUI
 - Success and Failure colors
 - Customize folder name and password
 - 10 attempt lockout (deletes folder and contents after 10 failed password attempts)
 - Encryption
 - Easter Eggs

## Reporting

Please read SECURITY.md for more information about reporting vulnerabilities.

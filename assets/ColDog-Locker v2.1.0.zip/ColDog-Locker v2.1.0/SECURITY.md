# Security Policy

## Supported Versions

| Version | Supported          |
| 2.1.x   | :heavy_check_mark: |
| ------- | ------------------ |
| 2.0.x   | :x:                |
| 1.2.x   | :x:                |
| 1.1.x   | :x:                |
| 1.0.x   | :x:                |

## Known Vulnerabilities

 - None

## Reporting a Vulnerability

To report a vulnerability, please contact the following email with a:

1. Picture or video proving the vulnerability (video preferred)
2. A brief discription of how you found the vulnerability
3. (Optional) how to fix the vulnerability

Email: coldog5044.business@gmail.com

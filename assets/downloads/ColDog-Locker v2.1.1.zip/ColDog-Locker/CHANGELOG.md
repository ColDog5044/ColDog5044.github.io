# ColDog-Locker Changelog

## v1.0.0
 - Average Joe Folder Locker to keep files hidden from the average user

## v1.1.0
 - Added colors for success and failure
 - Added CHANGELOG
 - Added README

## v1.1.1
 - Reorganized code

## v1.1.2
 - Added easter eggs

## v1.1.3
 - Reorganized code
 - Added support for multi-word locker names

## v1.2.0
 - Optimized code
 - Reorganized code
 - 10 attempt lockout (Folder and content is deleted after 10 failed password attempts)

## v1.2.1
 - Optimized code
 - Reorganized code
 - Windows 11 bug fixes
 - Choose folder name and password in startup configuration

## v1.2.2
 - Locker is secured more
 - Increased general security
 - Added SECURITY for reporting vulnerabilities
 - Added Bug Fixes
 - Added Feature Requests
 - Password is hidden when typing
 - Changed development to GitHub
 - Added .EXE file for more security

## v1.2.3
 - Optimized Code
 - Reorganized Code
 - Security Vulnerability fixed
 - Restricts blank text in folder and password fields
 - Added Crypto-Locker Fixer v1.0.0 to delete broken configuration

## v2.0.0
 - Public Release

## v2.0.1
 - Renamed Locker to ColDog-Locker to not be named after Malware
 - Code Optimizations

## v2.1.0
 - Bug Fixes
 - Utilizes Microsoft BitLocker to encrypt files
 - Fixed ColDog-Locker Fixer

# v2.1.1
 -Added password confirmation on creation

# Future Plans
 - Support for Linux
 - Support for macOS
